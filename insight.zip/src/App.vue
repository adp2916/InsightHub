<template>
  <v-app>
    <v-container class="grey lighten-5 pa-0" :fluid="true">
      <v-row no-gutters style="flex-wrap: nowrap;">
        <v-col min-width="250" class="flex-grow-0 flex-shrink-0">
          <MainNav :miniVariant="expandNavFlag" :navWidth="navWidth"></MainNav>
        </v-col>
        <v-col
          cols="1"
          style="min-width: 100px; max-width: 100%;"
          class="flex-grow-1 flex-shrink-0"
        >
          <AppBar @expandnav="toggaleexpandnav"></AppBar>
          <router-view></router-view>
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<script>
import upperFirst from 'lodash/upperFirst'
import MainNav from './components/MainNav.vue'
import AppBar from './components/AppBar.vue'

export default {
  name: 'App',
  data: function() {
    return {
      expandNavFlag: false,
      navWidth: 250,
      activeTabName: 'Home'
    }
  },
  methods: {
    toggaleexpandnav: function() {
      console.log('event received')
      this.expandNavFlag = !this.expandNavFlag
      this.navWidth = this.expandNavFlag ? 0 : 250
    },
    activeTab: function(item) {
      console.log(item)
      if (item.parent === 'self') {
        this.activeTabName = upperFirst(
          item.vname === 'qliksense' ? 'Qlik Sense' : item.vname
        )
      } else {
        this.activeTabName =
          upperFirst(item.parent === 'qliksense' ? 'Qlik Sense' : item.parent) +
          ' > ' +
          upperFirst(item.title)
      }
    }
  },
  components: {
    MainNav: MainNav,
    AppBar: AppBar
  }
}
</script>

<style scoped></style>
