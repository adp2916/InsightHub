import Vue from 'vue'
import Vuex from 'vuex'
import appList from '../../public/data/appList'
import stream from '../../public/data/streamList'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    activeTab: { parentId: 99999, id: 99999, name: 'Home', parent: '' },
    repTools: [
      {
        id: 1,
        name: 'Qlik Sense',
        vname: 'qliksense',
        img: 'qlik_sense_logo_0',
        type: 'mainNav'
      },
      {
        id: 2,
        name: 'Power Points',
        vname: 'ssrs',
        img: 'SSRS-icon',
        type: 'mainNav'
      },
      {
        id: 3,
        name: 'Monthly Insight',
        vname: 'others',
        img: 'other_report_icon',
        type: 'mainNav'
      }
    ],
    bookmarks: [],
    streams: {
      1: stream.streams,
      2: [],
      3: []
    },
    apps: appList.appList
  },
  mutations: {
    GET_ACTIVE_TAB: function(state, tabInfo) {
      state.activeTab = tabInfo
    },
    ADD_REMOVE_BOOKMARK: function(state, app) {
      let index = state.bookmarks.findIndex(bm => bm.id === app.id)
      console.log(index)
      if (index >= 0) {
        state.bookmarks.splice(index, 1)
      } else {
        state.bookmarks.push(app)
      }
    }
  },
  actions: {
    updateActiveTab: function({ commit }, tabInfo) {
      commit('GET_ACTIVE_TAB', tabInfo)
    },
    updateBookmarks: function({ commit }, app) {
      commit('ADD_REMOVE_BOOKMARK', app)
    }
  },
  getters: {
    navItems: function(state) {
      let tools = state.repTools
      let streams = state.streams
      let navList = []

      for (let i = 0; i < tools.length; i++) {
        navList.push({
          parentId: '99999',
          id: tools[i].id,
          name: tools[i].name,
          type: tools[i].type,
          vname: tools[i].vname,
          img: tools[i].img,
          parent: 'self'
        })
        let tStreams = streams[tools[i].id]
        for (let j = 0; j < tStreams.length; j++) {
          navList.push({
            parentId: tools[i].id,
            id: tStreams[j].id,
            name: tStreams[j].name,
            type: 'subNav',
            vname: 'stream',
            parent: tools[i].vname
          })
        }
      }

      return navList
    },
    activeTabTitle: function(state) {
      let parentId = state.activeTab.parentId

      let parent = state.repTools.filter(tool => {
        return tool.id == parentId
      })
      let parentName = parent[0] ? parent[0].name : ''

      let streamName =
        state.activeTab.name && parent[0]
          ? ' > ' + state.activeTab.name
          : state.activeTab.name

      return parentName + streamName
    },
    getAppsByStream: state => streamId => {
      return state.apps.filter(
        app => app.stream != null && app.stream.id === streamId
      )
    },
    getBookmarksByTool: state => toolId => {
      return state.bookmarks.filter(bookmark => bookmark.toolId === toolId)
    }
  },
  modules: {}
})
