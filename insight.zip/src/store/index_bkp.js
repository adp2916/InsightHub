import Vue from 'vue'
import Vuex from 'vuex'
import appList from '../../public/data/appList'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    activeTab: { parentId: 99999, id: 99999, name: 'Home', parent: '' },
    repTools: [
      {
        id: 1,
        name: 'Qlik Sense',
        vname: 'qliksense',
        img: 'qlik_sense_logo_0',
        type: 'mainNav'
      },
      {
        id: 2,
        name: 'SSRS Reporting',
        vname: 'ssrs',
        img: 'SSRS-icon',
        type: 'mainNav'
      },
      {
        id: 3,
        name: 'Others',
        vname: 'others',
        img: 'other_report_icon',
        type: 'mainNav'
      }
    ],
    streams: {
      1: [
        {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        {
          id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
          name: 'Sales',
          privileges: null
        }
      ],
      2: [],
      3: []
    },
    apps: [
      {
        id: '71ca1c28-656b-413b-825d-f4136783dff7',
        name: 'Section Access',
        appId: '',
        publishTime: '2019-11-30T04:38:45.643Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.145.3',
        migrationHash: '',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: '41908dd1-7a59-4bd0-8e64-f116d07d9356',
        name: 'Executive Dashboard',
        appId: '',
        publishTime: '2020-06-01T04:01:27.904Z',
        published: true,
        stream: {
          id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
          name: 'Sales',
          privileges: null
        },
        savedInProductVersion: '12.602.2',
        migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: '74e1a5f3-37b0-4dd0-a5d3-54637ca76604',
        name: 'Qlik Sense - Section Access',
        appId: '',
        publishTime: '2019-12-05T02:12:37.696Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.602.2',
        migrationHash: '',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: '1217ba2d-890e-4197-8f7a-1fd4da23588d',
        name: 'Executive Dashboard',
        appId: '',
        publishTime: '2019-12-05T03:13:23.498Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.421.3',
        migrationHash: '',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: 'b63af1a6-41d0-4f5f-8401-b6017af8bd19',
        name: 'Customer Experience',
        appId: '',
        publishTime: '2019-12-05T03:16:15.304Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.421.3',
        migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: '641a2f89-67dd-4d04-a393-a8aafa0d0252',
        name: 'Vintage Movies',
        appId: '',
        publishTime: '2020-04-30T04:24:40.028Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.170.2',
        migrationHash: '98d482c3f964dccf69cbfb9a00e0c048ea6eb221',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: 'c3d05bc2-0458-43f6-9eb9-944fc9337a24',
        name: 'Quality Dashboard',
        appId: '',
        publishTime: '2020-06-01T03:12:27.042Z',
        published: true,
        stream: {
          id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
          name: 'Sales',
          privileges: null
        },
        savedInProductVersion: '12.602.2',
        migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: '1ed952f2-0e27-488e-abf6-0530e0d02cbb',
        name: 'Qlik Sense -  Challenge',
        appId: '',
        publishTime: '2020-07-19T17:00:52.932Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.421.3',
        migrationHash: '',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      },
      {
        id: 'ecbdfdbf-5862-4ecf-8f1d-822aee592be2',
        name: 'Qlik Sense -  Solution - Multi-Field Data Reduction',
        appId: '',
        publishTime: '2019-12-21T21:20:42.115Z',
        published: true,
        stream: {
          id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
          name: 'Everyone',
          privileges: null
        },
        savedInProductVersion: '12.421.3',
        migrationHash: '',
        availabilityStatus: 1,
        privileges: ['read', 'offlineaccess']
      }
    ]
  },
  mutations: {
    GET_ACTIVE_TAB: function(state, tabInfo) {
      state.activeTab = tabInfo
    }
  },
  actions: {
    updateActiveTab: function({ commit }, tabInfo) {
      commit('GET_ACTIVE_TAB', tabInfo)
    }
  },
  getters: {
    navItems: function(state) {
      let tools = state.repTools
      let streams = state.streams
      let navList = []

      for (let i = 0; i < tools.length; i++) {
        navList.push({
          parentId: '99999',
          id: tools[i].id,
          name: tools[i].name,
          type: tools[i].type,
          vname: tools[i].vname,
          img: tools[i].img,
          parent: 'self'
        })
        let tStreams = streams[tools[i].id]
        for (let j = 0; j < tStreams.length; j++) {
          navList.push({
            parentId: tools[i].id,
            id: tStreams[j].id,
            name: tStreams[j].name,
            type: 'subNav',
            vname: 'stream',
            parent: tools[i].vname
          })
        }
      }

      return navList
    },
    activeTabTitle: function(state) {
      let parentId = state.activeTab.parentId

      let parent = state.repTools.filter(tool => {
        return tool.id == parentId
      })
      let parentName = parent[0] ? parent[0].name : ''

      let streamName =
        state.activeTab.name && parent[0]
          ? ' > ' + state.activeTab.name
          : state.activeTab.name

      return parentName + streamName
    },
    getAppsByStream: state => streamId => {
      return state.apps.filter(app => app.stream.id === streamId)
    }
  },
  modules: {}
})
