<template>
  <div>SSRS Reports {{ toolId }}</div>
</template>

<script>
export default {
  props: {
    toolId: [Number, String]
  }
}
</script>

<style lang="scss" scoped></style>
