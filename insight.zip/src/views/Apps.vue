<template>
  <v-app>
    <div class="d-flex flex-wrap">
      <div
        v-for="app in getAppsByStream(streamId)"
        :key="app.id"
        class="flex-grow-1 "
      >
        <AppCard :app="app" :toolId="toolId" :streamId="streamId"> </AppCard>
      </div>
    </div>
  </v-app>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import AppCard from '@/components/AppCard.vue'
export default {
  components: { AppCard: AppCard },
  props: {
    toolId: [String, Number],
    streamId: [String, Number]
  },

  computed: {
    localComputed() {
      return 'localProps'
    },
    ...mapGetters(['navItems', 'getAppsByStream']),
    ...mapState({
      appName: state => state.apps[0].name,
      appId: state => state.apps[0].id
    })
  }
}
</script>

<style lang="scss" scoped>
.card-size {
  max-width: 500px;
}
</style>
