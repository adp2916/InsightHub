<template>
  <v-app>
    <div class="d-flex">
      <div>
        <MainNav />
      </div>
      <div>
        <AppBar />
        <router-view></router-view>
      </div>
    </div>
  </v-app>
</template>

<script>
import MainNav from "./components/MainNav.vue";
import AppBar from "./components/AppBar.vue";

export default {
  name: "App",

  components: {
    MainNav: MainNav,
    AppBar: AppBar,
  },

  data: () => ({
    //
  }),
};
</script>

<style scoped></style>
