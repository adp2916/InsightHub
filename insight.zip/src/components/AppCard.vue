<template>
  <div class="card-main">
    <v-hover>
      <template v-slot="{ hover }">
        <v-card
          :elevation="hover ? 12 : 1"
          class="mx-auto card-main"
          color="grey lighten-3"
        >
          <div class="d-flex flex-no-wrap justify-space-between">
            <div>
              <v-card-title h4 v-text="app.name"></v-card-title>
              <v-tooltip v-model="show" bottom max-width="400">
                <template v-slot:activator="{ on, attrs }">
                  <v-card-subtitle
                    v-bind="attrs"
                    v-on="on"
                    v-text="
                      app.description.length ? app.description + '...' : ''
                    "
                    class="text-wrap"
                    :class="app.description.length ? 'app-desc-size' : ''"
                  ></v-card-subtitle>
                </template>
                <span v-if="app.description.length">{{ app.description }}</span>
              </v-tooltip>
            </div>

            <v-avatar class="ma-3" size="125" tile>
              <v-img :src="'/img/' + 'temp-dashboard' + '.png'"></v-img>
            </v-avatar>
          </div>
          <div>
            <v-card-actions>
              <v-btn
                v-if="!toggleBookmarkIcon"
                x-small
                class="ma-2"
                outlined
                fab
                color="teal"
                @click="toggleBookmark(appInfo)"
              >
                <v-icon>mdi-star</v-icon>
              </v-btn>
              <v-btn
                v-if="toggleBookmarkIcon"
                x-small
                class="mx-2"
                fab
                dark
                color="teal"
                @click="toggleBookmark(appInfo)"
              >
                <v-icon dark>
                  mdi-star
                </v-icon>
              </v-btn>
              <v-btn x-small class="ma-2" outlined fab color="teal">
                <v-icon>mdi-eye-outline </v-icon>
              </v-btn>
            </v-card-actions>
          </div>
        </v-card>
      </template>
    </v-hover>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    app: Object,
    toolId: [String, Number],
    streamId: [String, Number]
  },
  data: function() {
    return {
      show: false
    }
  },
  methods: {
    toggleBookmark: function(app) {
      this.$store.dispatch('updateBookmarks', app) //updateActiveTab is action in store
    }
  },
  computed: {
    appInfo: function() {
      let app = this.app
      app['toolId'] = this.toolId
      app['streamId'] = this.streamId
      return app
    },
    toggleBookmarkIcon: function() {
      let bookmarks = this.getBookmarksByTool(this.toolId)
      let checkApp = bookmarks.filter(bm => bm.id === this.app.id)
      return checkApp.length > 0
    },
    ...mapGetters(['getBookmarksByTool'])
  }
}
</script>

<style scoped>
.card-main {
  margin: 10px;
  min-width: 500px;
  max-width: 800px;
}

.app-desc-size {
  width: 300px;
  height: 80px;
  overflow: hidden;
}
/* .v-card__text {
  max-width: 500px !important;
} */
</style>
