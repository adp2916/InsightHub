<template>
  <div>
    <v-app-bar color="grey lighten-3" dense>
      <v-app-bar-nav-icon v-on:click="navExpandToggle()"></v-app-bar-nav-icon>

      <v-toolbar-title>{{ activeTabTitle }}</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-menu left bottom>
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon v-bind="attrs" v-on="on">
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item v-for="n in 5" :key="n" @click="() => {}">
            <v-list-item-title>Option {{ n }}</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    activeTabName: String
  },
  methods: {
    navExpandToggle: function() {
      // console.log("Expand nav Clicked");
      this.$emit('expandnav')
    }
  },
  computed: {
    ...mapGetters(['activeTabTitle'])
  }
}
</script>
