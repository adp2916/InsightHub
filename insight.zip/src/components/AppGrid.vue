<template>
  <v-container class="grey lighten-5">
    <v-row no-gutters style="flex-wrap: nowrap;">
      <v-col cols="2" class="flex-grow-0 flex-shrink-0">
        <v-card class="pa-2" outlined tile>
          I'm 2 column wide
        </v-card>
      </v-col>
      <v-col
        cols="1"
        style="min-width: 100px; max-width: 100%;"
        class="flex-grow-1 flex-shrink-0"
      >
        <v-card class="pa-2" outlined tile>
          I'm 1 column wide and I grow to take all the space
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>
