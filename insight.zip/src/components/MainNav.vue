<template>
  <v-card height="100vh" :width="navWidth">
    <v-navigation-drawer
      :expand-on-hover="expandOnHover"
      :mini-variant="miniVariant"
      :right="right"
      :permanent="permanent"
      :src="bg"
      absolute
      color="#333"
      class="v-image__image v-image__image--cover i-navigation-drawer-image"
    >
      <router-link to="/" class="i-header">
        <v-list-item-content @click="updateActiveTab(home)">
          <v-list-item-title class="title">Insight</v-list-item-title>
          <v-list-item-subtitle>Analytics Portal</v-list-item-subtitle>
        </v-list-item-content>
      </router-link>

      <v-divider></v-divider>

      <v-list nav>
        <v-list-item
          v-for="item in navItems"
          :key="item.name"
          :to="getViewLink(item)"
          :class="[
            item.type === 'subNav' ? 'i-subNav-left-border' : '',
            item.type === 'subNav' ? 'i-subNav' : 'i-mainNav'
          ]"
          @click="updateActiveTab(item)"
          link
        >
          <!-- <router-link :to="{ name: item.vname }"> -->

          <img
            v-if="item.type == 'mainNav'"
            :src="'/img/' + item.img + '.png'"
            width="25px"
            height="auto"
            class="i-nav-img"
          />

          <v-list-item-content>
            <v-list-item-title>{{ item.name }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
  </v-card>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
export default {
  props: {
    miniVariant: Boolean,
    navWidth: Number
  },
  data() {
    return {
      home: {
        id: 99999,
        parentId: 99999,
        name: 'Home',
        type: 'mainNav',
        vname: 'Home',
        parent: 'self'
      },
      color: 'primary',
      colors: ['primary', 'blue', 'success', 'red', 'teal'],
      right: false,
      permanent: true,
      //miniVariant: false,
      expandOnHover: false,
      // eslint-disable-next-line
      background: false
    }
  },
  methods: {
    getImgUrl: function(pic) {
      return require('../../public/' + pic + '.png')
    },
    getViewLink: function(item) {
      //console.log(item)
      let link = ''
      if (item.type === 'mainNav') {
        link = { name: item.vname, params: { toolId: item.id } }
      } else {
        link = ''
        link = {
          name: item.vname,
          params: { toolId: item.parentId, streamId: item.id }
        }
      }
      // console.log('link', link)

      return link
    },
    updateActiveTab: function(item) {
      this.$store.dispatch('updateActiveTab', item) //updateActiveTab is action in store
    }
  },
  computed: {
    bg() {
      return this.background
        ? 'https://demos.creative-tim.com/material-dashboard/assets/img/sidebar-1.jpg'
        : undefined
      // eslint-disable-next-line
    },
    ...mapGetters(['navItems']),
    ...mapState({
      appName: state => state.apps[0].name,
      appId: state => state.apps[0].id
    })
    // eslint-disable-next-line
  }
}
</script>

<style scoped>
.i-navigation-drawer-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)),
    url('https://demos.creative-tim.com/material-dashboard/assets/img/sidebar-1.jpg');
}
.i-header {
  text-decoration: none;
  padding: 0 16px;
  display: flex;
}
.i-nav-img {
  margin-right: 20px;
}

.i-subNav-left-border {
  border-left: 2px solid #ccc;
  border-radius: 0px !important;
  margin-left: 50px !important;
  margin-bottom: 0px !important;
}
.v-card {
  border-radius: 0px !important;
}

.v-list-item--active.i-mainNav {
  background: #666;
}
.v-list-item--active.i-subNav {
  background: #4caf50;
}

.v-list-item__subtitle,
.v-list-item__title,
.v-icon {
  color: white !important;
}

.v-divider {
  color: #bbb;
  border-color: #777 !important;
  margin: 0px 10px !important;
}
</style>
