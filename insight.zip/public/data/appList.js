export default {
  appList: [
    {
      id: '1d86e065-15f0-4ea6-8e8c-043d3920ad0b',
      createdDate: '2019-11-18T02:15:40.493Z',
      modifiedDate: '2019-11-30T04:30:44.157Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [
        {
          id: '43c91cf4-01e8-4341-96da-4cecdf580399',
          createdDate: '2019-11-30T04:30:44.157Z',
          modifiedDate: '2019-11-30T04:30:44.157Z',
          modifiedByUserName: 'IPORTAL\\a_wilson',
          value: 'Finance',
          definition: {
            id: 'ce28b03b-d926-4158-a0e2-3f66238d3add',
            name: 'StreamAccess',
            valueType: 'Text',
            choiceValues: [],
            privileges: null
          },
          schemaPath: 'CustomPropertyValue'
        }
      ],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Peer Dashboard',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-11-30T04:27:31.322Z',
      published: true,
      tags: [],
      description: '',
      stream: {
        id: 'ded5c2da-f0e6-41af-bd6b-9df050412b87',
        name: 'Finance',
        privileges: null
      },
      fileSize: 150817,
      lastReloadTime: '2019-11-18T04:07:48.551Z',
      thumbnail: '',
      savedInProductVersion: '12.421.3',
      migrationHash: '21ecc792c56e18162f1785d3d41f28fdaced5c96',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '71ca1c28-656b-413b-825d-f4136783dff7',
      createdDate: '2019-11-30T04:21:03.685Z',
      modifiedDate: '2019-11-30T04:38:45.669Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Data Dictionary',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-11-30T04:38:45.643Z',
      published: true,
      tags: [],
      description: '',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 148776,
      lastReloadTime: '2019-10-01T15:20:39.954Z',
      thumbnail: '',
      savedInProductVersion: '12.145.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '3f51f911-a4f1-4bf1-b0b6-21107eac3d81',
      createdDate: '2019-12-01T23:20:22.552Z',
      modifiedDate: '2019-12-01T23:29:43.910Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [
        {
          id: '063e7899-5a87-4fc6-a1a5-f74be32905eb',
          createdDate: '2019-12-01T23:29:43.910Z',
          modifiedDate: '2019-12-01T23:29:43.910Z',
          modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
          value: 'User Detail',
          definition: {
            id: 'faafe063-0d8c-40a9-a7a2-5037e8314ded',
            name: 'HideSheets',
            valueType: 'Text',
            choiceValues: [],
            privileges: null
          },
          schemaPath: 'CustomPropertyValue'
        },
        {
          id: 'fcc42b82-8aef-4a1d-a4a0-a18a06593e84',
          createdDate: '2019-12-01T23:29:43.910Z',
          modifiedDate: '2019-12-01T23:29:43.910Z',
          modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
          value: 'Timeline',
          definition: {
            id: 'faafe063-0d8c-40a9-a7a2-5037e8314ded',
            name: 'HideSheets',
            valueType: 'Text',
            choiceValues: [],
            privileges: null
          },
          schemaPath: 'CustomPropertyValue'
        }
      ],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'License Monitor',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: 'f7f8c7bc-c635-41ce-950e-2e57e8a8cfd9',
      publishTime: '2019-12-01T23:20:39.110Z',
      published: true,
      tags: [],
      description:
        'The License Monitor 7.18 tracks license usage and facilitates efficient allocation of licenses and tokens. Includes the ability to assess Token-based usage or Analyzer/Professional/Analyzer Capacity usage, or Unified License usage (dual use of Sense and QlikView). Enjoy!',
      stream: {
        id: 'bf138b70-59d3-471b-92e3-b31761caa348',
        name: 'IT',
        privileges: null
      },
      fileSize: 351934,
      lastReloadTime: '2019-12-01T22:40:57.440Z',
      thumbnail:
        '/appcontent/3f51f911-a4f1-4bf1-b0b6-21107eac3d81/Icon_License_grey.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '98d482c3f964dccf69cbfb9a00e0c048ea6eb221',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'eb38cc0f-a92b-431c-abba-5fa66466c437',
      createdDate: '2019-12-02T00:46:11.541Z',
      modifiedDate: '2019-12-02T00:46:27.362Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Travel Expense Management(1)',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '3567934e-147f-40ff-b9c0-44d9694b19a7',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description:
        "Every company has expenses. Every sales or services company has traveling costs. But most expense tools don't give you the insight information about how the expenses were spent. \n\nThis Travel Expense Management application provides you with a way to discover unexpected expenses and track employee travel and food spending. \n\nExternal data is used in this application to look at US airfare costs and US per diem rates.",
      stream: null,
      fileSize: 2655927,
      lastReloadTime: '2014-07-30T18:58:12.000Z',
      thumbnail:
        '/appcontent/eb38cc0f-a92b-431c-abba-5fa66466c437/cbo_thumb-travel_expense_management.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '3567934e-147f-40ff-b9c0-44d9694b19a7',
      createdDate: '2019-12-01T18:02:34.004Z',
      modifiedDate: '2019-12-02T00:47:14.688Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Market Development Scorecard',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-12-01T18:04:45.733Z',
      published: true,
      tags: [],
      description:
        "Every company has expenses. Every sales or services company has traveling costs. But most expense tools don't give you the insight information about how the expenses were spent. \n\nThis Travel Expense Management application provides you with a way to discover unexpected expenses and track employee travel and food spending. \n\nExternal data is used in this application to look at US airfare costs and US per diem rates.",
      stream: {
        id: 'ded5c2da-f0e6-41af-bd6b-9df050412b87',
        name: 'Finance',
        privileges: null
      },
      fileSize: 2655927,
      lastReloadTime: '2014-07-30T18:58:12.000Z',
      thumbnail:
        '/appcontent/3567934e-147f-40ff-b9c0-44d9694b19a7/cbo_thumb-travel_expense_management.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '41908dd1-7a59-4bd0-8e64-f116d07d9356',
      createdDate: '2020-06-01T04:01:25.322Z',
      modifiedDate: '2020-06-01T04:01:28.019Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Solution Center Dashboard',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-06-01T04:01:27.904Z',
      published: true,
      tags: [],
      description:
        'Executive Dashboard is for senior managers to monitor performance within their business, giving them both a high level view as well as the ability to drill down into the granular details of the business. In this example, the organization manufactures fast moving consumables, using a reseller model to distribute its products across multiple regions.',
      stream: {
        id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
        name: 'Sales',
        privileges: null
      },
      fileSize: 1505715,
      lastReloadTime: '2014-06-27T15:51:29.000Z',
      thumbnail: '/media/thumb-executive_dashboard.png',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '74e1a5f3-37b0-4dd0-a5d3-54637ca76604',
      createdDate: '2019-12-05T01:39:03.541Z',
      modifiedDate: '2020-09-06T20:46:20.468Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Active Directory Accounts',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-12-05T02:12:37.696Z',
      published: true,
      tags: [],
      description: '',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 310690,
      lastReloadTime: '2020-09-06T20:46:19.604Z',
      thumbnail:
        '/appcontent/74e1a5f3-37b0-4dd0-a5d3-54637ca76604/Linearregression.jpg',
      savedInProductVersion: '12.602.2',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'b670db9f-29af-4c99-a749-4ea7adfca668',
      createdDate: '2019-12-01T18:02:25.389Z',
      modifiedDate: '2020-03-07T18:37:47.546Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Sales Management and Customers Analysis',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description:
        'Do you know which products are popular on based on customer demographics, regions, time of year, holidays, etc so that you can optimize your marketing and sales efforts to support the greatest amount of revenue?\n\nIf you begin selling more product to more (or the same) customers do you have the proper infrastructure to support product returns/exchanges to delight those customers enough for them to return to you?',
      stream: null,
      fileSize: 20131271,
      lastReloadTime: '2015-01-22T21:30:20.000Z',
      thumbnail:
        '/appcontent/b670db9f-29af-4c99-a749-4ea7adfca668/CDP-Sales_Performance_Pipeline_And_Productivity-Coloring_Example.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'bca57bda-d3a6-4061-aca2-99ff9ebb74f6',
      createdDate: '2019-12-01T18:02:16.288Z',
      modifiedDate: '2020-04-07T03:29:06.483Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [
        {
          id: '70592012-2974-458e-9a9f-098eb1431558',
          createdDate: '2019-12-01T18:04:15.171Z',
          modifiedDate: '2020-04-07T03:29:06.483Z',
          modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
          value: 'Executive',
          definition: {
            id: '4ec54a8b-7d5c-42f8-8656-eed7668d96f4',
            name: 'AppLevelMgmt',
            valueType: 'Text',
            choiceValues: [],
            privileges: null
          },
          schemaPath: 'CustomPropertyValue'
        },
        {
          id: '755f1769-4df0-4923-9a39-ecbcbf6f60ab',
          createdDate: '2019-12-01T18:04:15.171Z',
          modifiedDate: '2020-04-07T03:29:06.483Z',
          modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
          value: 'Sales',
          definition: {
            id: '96d5b531-0ed6-44f0-8e5a-947ef1dba124',
            name: 'ManagedMasterItems',
            valueType: 'Text',
            choiceValues: [],
            privileges: null
          },
          schemaPath: 'CustomPropertyValue'
        }
      ],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Executive Dashboard',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-12-01T18:03:34.828Z',
      published: true,
      tags: [],
      description:
        'Executive Dashboard is for senior managers to monitor performance within their business, giving them both a high level view as well as the ability to drill down into the granular details of the business. In this example, the organization manufactures fast moving consumables, using a reseller model to distribute its products across multiple regions.',
      stream: {
        id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
        name: 'Sales',
        privileges: null
      },
      fileSize: 1505715,
      lastReloadTime: '2014-06-27T15:51:29.000Z',
      thumbnail:
        '/appcontent/bca57bda-d3a6-4061-aca2-99ff9ebb74f6/thumb-executive_dashboard.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '21ac3733-03c7-45d7-8d1f-8507d8bc284a',
      createdDate: '2019-11-07T01:35:38.151Z',
      modifiedDate: '2020-09-13T18:40:58.648Z',
      modifiedByUserName: 'INTERNAL\\sa_scheduler',
      customProperties: [],
      owner: {
        id: 'f7c1201f-9873-4193-b89f-68c9fccdbfb8',
        userId: 'sa_repository',
        userDirectory: 'INTERNAL',
        name: 'sa_repository',
        privileges: null
      },
      name: 'Operations Monitor',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-04-22T02:30:30.057Z',
      published: true,
      tags: [],
      description:
        'The Operations Monitor 7.16 provides information about the Qlik Sense server environment, including: server memory and CPU usage, active users, task reloads, and errors and warnings.  Enjoy!',
      stream: {
        id: 'a70ca8a5-1d59-4cc9-b5fa-6e207978dcaf',
        name: 'Monitoring apps',
        privileges: null
      },
      fileSize: 684864,
      lastReloadTime: '2020-09-13T18:40:58.245Z',
      thumbnail:
        '/appcontent/21ac3733-03c7-45d7-8d1f-8507d8bc284a/Icon_KPI_Dashboard_grey.png',
      savedInProductVersion: '12.602.2',
      migrationHash: '21ecc792c56e18162f1785d3d41f28fdaced5c96',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '34fdaa9a-5350-46c1-a2e5-3bf09d99303b',
      createdDate: '2019-12-05T02:05:40.534Z',
      modifiedDate: '2020-09-06T20:45:52.264Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Data Dictionary',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '74e1a5f3-37b0-4dd0-a5d3-54637ca76604',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 308001,
      lastReloadTime: '2019-12-03T16:21:23.652Z',
      thumbnail:
        '/appcontent/34fdaa9a-5350-46c1-a2e5-3bf09d99303b/Linearregression.jpg',
      savedInProductVersion: '12.602.2',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'b63af1a6-41d0-4f5f-8401-b6017af8bd19',
      createdDate: '2019-12-05T03:15:51.914Z',
      modifiedDate: '2020-04-14T01:29:03.961Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Customer Experience',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-12-05T03:16:15.304Z',
      published: true,
      tags: [],
      description:
        'This application looks at Customer Advocacy, in terms of Net Promoter Score, alongside Customer Satisfaction to identify key products which not only yield profits but ensure quality customer service and benefit retention.',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 19988936,
      lastReloadTime: '2015-05-06T13:15:19.000Z',
      thumbnail:
        '/appcontent/b63af1a6-41d0-4f5f-8401-b6017af8bd19/thumbnail_CustomerExperienceTelco.jpg',
      savedInProductVersion: '12.421.3',
      migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '053c8b6a-6f98-4748-a045-8fcaaa1359b4',
      createdDate: '2020-04-22T02:30:15.983Z',
      modifiedDate: '2020-04-22T02:30:19.196Z',
      modifiedByUserName: 'INTERNAL\\sa_repository',
      customProperties: [],
      owner: {
        id: 'f7c1201f-9873-4193-b89f-68c9fccdbfb8',
        userId: 'sa_repository',
        userDirectory: 'INTERNAL',
        name: 'sa_repository',
        privileges: null
      },
      name: 'License Monitor_26.2.3.0',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: 'f7f8c7bc-c635-41ce-950e-2e57e8a8cfd9',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description:
        'The License Monitor 7.18 tracks license usage and facilitates efficient allocation of licenses and tokens. Includes the ability to assess Token-based usage or Analyzer/Professional/Analyzer Capacity usage, or Unified License usage (dual use of Sense and QlikView). Enjoy!',
      stream: null,
      fileSize: 1010519,
      lastReloadTime: '2020-04-15T05:40:51.651Z',
      thumbnail:
        '/appcontent/053c8b6a-6f98-4748-a045-8fcaaa1359b4/Icon_License_grey.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '98d482c3f964dccf69cbfb9a00e0c048ea6eb221',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '57938611-90df-40d2-b1fe-4325ead327d5',
      createdDate: '2020-04-22T02:41:29.917Z',
      modifiedDate: '2020-04-22T02:41:29.917Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\qsadmin',
      customProperties: [],
      owner: {
        id: 'd550b997-507d-44cd-a459-ae015410a00b',
        userId: 'qsadmin',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'qsadmin',
        privileges: null
      },
      name: 'Demo-Test',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 139768,
      lastReloadTime: '1753-01-01T00:00:00.000Z',
      thumbnail: '',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '80b8fb6d-d230-49cc-be4b-e0fb685373dd',
      createdDate: '2020-04-22T02:30:26.068Z',
      modifiedDate: '2020-04-22T02:30:27.178Z',
      modifiedByUserName: 'INTERNAL\\sa_repository',
      customProperties: [],
      owner: {
        id: 'f7c1201f-9873-4193-b89f-68c9fccdbfb8',
        userId: 'sa_repository',
        userDirectory: 'INTERNAL',
        name: 'sa_repository',
        privileges: null
      },
      name: 'Operations Monitor_26.2.3.0',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '21ac3733-03c7-45d7-8d1f-8507d8bc284a',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description:
        'The Operations Monitor 7.16 provides information about the Qlik Sense server environment, including: server memory and CPU usage, active users, task reloads, and errors and warnings. Enjoy!',
      stream: null,
      fileSize: 2757245,
      lastReloadTime: '2020-04-15T05:40:56.953Z',
      thumbnail:
        '/appcontent/80b8fb6d-d230-49cc-be4b-e0fb685373dd/Icon_KPI_Dashboard_grey.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '98d482c3f964dccf69cbfb9a00e0c048ea6eb221',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '23341955-8cdd-41ff-82e2-f5383fb2aad3',
      createdDate: '2020-05-24T19:27:54.043Z',
      modifiedDate: '2020-05-24T19:27:56.387Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\ah_contributor',
      customProperties: [],
      owner: {
        id: '7f330d55-329f-41c4-ae69-898b5022570e',
        userId: 'ah_contributor',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'ah_contributor',
        privileges: null
      },
      name: 'DataManagerDemo',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 325590,
      lastReloadTime: '2020-05-23T21:43:39.807Z',
      thumbnail: '',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '612bd2c2-8571-4712-a08d-abf58a318525',
      createdDate: '2020-05-26T19:33:22.851Z',
      modifiedDate: '2020-05-26T19:33:22.851Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\ah_contributor',
      customProperties: [],
      owner: {
        id: '7f330d55-329f-41c4-ae69-898b5022570e',
        userId: 'ah_contributor',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'ah_contributor',
        privileges: null
      },
      name: 'LoadingDataFromFlatFiles',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 139770,
      lastReloadTime: '1753-01-01T00:00:00.000Z',
      thumbnail: '',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '641a2f89-67dd-4d04-a393-a8aafa0d0252',
      createdDate: '2020-04-30T04:24:24.069Z',
      modifiedDate: '2020-04-30T04:24:40.122Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'ServiceNow Analytics',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-04-30T04:24:40.028Z',
      published: true,
      tags: [],
      description:
        'The database contains over 1,700 tickets spanning 180 years. View tickets by department, business functions, duration, and priority. Create your own visualizations and see what new insights you can find!',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 237520,
      lastReloadTime: '2014-11-07T08:02:54.000Z',
      thumbnail:
        '/appcontent/641a2f89-67dd-4d04-a393-a8aafa0d0252/thumb-vintage_movies.png',
      savedInProductVersion: '12.170.2',
      migrationHash: '98d482c3f964dccf69cbfb9a00e0c048ea6eb221',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'c3d05bc2-0458-43f6-9eb9-944fc9337a24',
      createdDate: '2020-06-01T03:12:21.709Z',
      modifiedDate: '2020-06-01T03:12:27.213Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Executive Dashboard',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-06-01T03:12:27.042Z',
      published: true,
      tags: [],
      description:
        'Executive Dashboard is for senior managers to monitor performance within their business, giving them both a high level view as well as the ability to drill down into the granular details of the business. In this example, the organization manufactures fast moving consumables, using a reseller model to distribute its products across multiple regions.',
      stream: {
        id: '47205245-5163-410a-a423-62f9f40667fb',
        name: 'Executive',
        privileges: null
      },
      fileSize: 1505715,
      lastReloadTime: '2014-06-27T15:51:29.000Z',
      thumbnail: '/media/thumb-executive_dashboard.png',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'f7f8c7bc-c635-41ce-950e-2e57e8a8cfd9',
      createdDate: '2019-11-07T01:35:34.342Z',
      modifiedDate: '2020-09-13T18:40:53.091Z',
      modifiedByUserName: 'INTERNAL\\sa_scheduler',
      customProperties: [],
      owner: {
        id: 'f7c1201f-9873-4193-b89f-68c9fccdbfb8',
        userId: 'sa_repository',
        userDirectory: 'INTERNAL',
        name: 'sa_repository',
        privileges: null
      },
      name: 'License Monitor',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-04-22T02:30:22.020Z',
      published: true,
      tags: [],
      description:
        'The License Monitor 7.18 tracks license usage and facilitates efficient allocation of licenses and tokens. Includes the ability to assess Token-based usage or Analyzer/Professional/Analyzer Capacity usage, or Unified License usage (dual use of Sense and QlikView). Enjoy!',
      stream: {
        id: 'a70ca8a5-1d59-4cc9-b5fa-6e207978dcaf',
        name: 'Monitoring apps',
        privileges: null
      },
      fileSize: 1187503,
      lastReloadTime: '2020-09-13T18:40:52.558Z',
      thumbnail:
        '/appcontent/f7f8c7bc-c635-41ce-950e-2e57e8a8cfd9/Icon_License_grey.png',
      savedInProductVersion: '12.602.2',
      migrationHash: '21ecc792c56e18162f1785d3d41f28fdaced5c96',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'b727acee-841e-459d-bb4a-e13296e127bf',
      createdDate: '2020-05-26T16:32:08.132Z',
      modifiedDate: '2020-05-26T16:37:08.780Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\ah_contributor',
      customProperties: [],
      owner: {
        id: '7f330d55-329f-41c4-ae69-898b5022570e',
        userId: 'ah_contributor',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'ah_contributor',
        privileges: null
      },
      name: 'AttacheFileDemo',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 151284,
      lastReloadTime: '2020-05-26T16:37:07.919Z',
      thumbnail: '',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'd8637928-48bf-497c-be19-84ade6062efd',
      createdDate: '2020-04-09T05:18:54.918Z',
      modifiedDate: '2020-04-09T05:18:56.549Z',
      modifiedByUserName: 'QS-ANALYTICSHUB\\analyticshub_io',
      customProperties: [],
      owner: {
        id: 'd3dde3f4-0698-4c9f-bef2-a2ee8b3255d5',
        userId: 'analyticshub_io',
        userDirectory: 'QS-ANALYTICSHUB',
        name: 'analyticshub_io',
        privileges: null
      },
      name: 'Travel Expense Management(2)',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '3567934e-147f-40ff-b9c0-44d9694b19a7',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description:
        "Every company has expenses. Every sales or services company has traveling costs. But most expense tools don't give you the insight information about how the expenses were spent. \n\nThis Travel Expense Management application provides you with a way to discover unexpected expenses and track employee travel and food spending. \n\nExternal data is used in this application to look at US airfare costs and US per diem rates.",
      stream: null,
      fileSize: 2655927,
      lastReloadTime: '2014-07-30T18:58:12.000Z',
      thumbnail:
        '/appcontent/d8637928-48bf-497c-be19-84ade6062efd/cbo_thumb-travel_expense_management.png',
      savedInProductVersion: '12.421.3',
      migrationHash: '70d91dda7b305e84877b75bd813942ca309db502',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '1ed952f2-0e27-488e-abf6-0530e0d02cbb',
      createdDate: '2019-12-21T19:39:47.489Z',
      modifiedDate: '2020-07-19T17:00:52.935Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Learning Calendar',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2020-07-19T17:00:52.932Z',
      published: true,
      tags: [],
      description: 'Generic Keys',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 312130,
      lastReloadTime: '2019-12-21T19:35:53.146Z',
      thumbnail: '/appcontent/1ed952f2-0e27-488e-abf6-0530e0d02cbb/AI.PNG',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '72196efa-b62b-4bd4-b2d7-107aa511fec2',
      createdDate: '2020-07-19T17:11:20.734Z',
      modifiedDate: '2020-07-19T17:11:20.734Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Test',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 139767,
      lastReloadTime: '1753-01-01T00:00:00.000Z',
      thumbnail: '',
      savedInProductVersion: '12.602.2',
      migrationHash: '504d4e39a7133ee172fbe29aa58348b1e4054149',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'ecbdfdbf-5862-4ecf-8f1d-822aee592be2',
      createdDate: '2019-12-21T20:54:14.641Z',
      modifiedDate: '2019-12-21T21:20:42.159Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Infrastructure Patch Schedule',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '2019-12-21T21:20:42.115Z',
      published: true,
      tags: [],
      description: 'Generic Keys',
      stream: {
        id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
        name: 'Everyone',
        privileges: null
      },
      fileSize: 314625,
      lastReloadTime: '2019-12-21T21:20:07.412Z',
      thumbnail: '/appcontent/ecbdfdbf-5862-4ecf-8f1d-822aee592be2/AI.PNG',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '9f30d4de-5028-4ccc-acc1-b13a90742cb9',
      createdDate: '2019-12-21T20:32:42.878Z',
      modifiedDate: '2019-12-21T21:20:52.331Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Qlik Sense -  Challenge - Multi-Field Data Reduction',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: 'Generic Keys',
      stream: null,
      fileSize: 314632,
      lastReloadTime: '2019-12-21T20:30:50.283Z',
      thumbnail: '/appcontent/9f30d4de-5028-4ccc-acc1-b13a90742cb9/AI.PNG',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: '673c3182-3ae5-4f47-bcec-73c2b216716f',
      createdDate: '2019-12-21T20:07:36.120Z',
      modifiedDate: '2019-12-21T21:21:01.384Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'd74d040e-8dae-4396-a237-314ebbea0ebd',
        userId: 'a_wilson',
        userDirectory: 'IPORTAL',
        name: 'Amy Wilson',
        privileges: null
      },
      name: 'Qlik Sense -  Multi Field Data Reduction - Solution File',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: 'Generic Keys',
      stream: null,
      fileSize: 312137,
      lastReloadTime: '2019-12-21T19:35:53.146Z',
      thumbnail: '/appcontent/673c3182-3ae5-4f47-bcec-73c2b216716f/AI.PNG',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    },
    {
      id: 'dc3a7943-f6e9-46f9-93fa-c2c20d508093',
      createdDate: '2019-12-11T02:52:02.437Z',
      modifiedDate: '2020-01-15T22:47:26.000Z',
      modifiedByUserName: 'IPORTAL\\a_wilson',
      customProperties: [],
      owner: {
        id: 'e6731b7f-255e-4e10-8c41-ba2edd22fcf1',
        userId: 'a_foster',
        userDirectory: 'IPORTAL',
        name: 'Anne Foster',
        privileges: null
      },
      name: 'Qlik Sense - Section Access(1)',
      appId: '',
      sourceAppId: '00000000-0000-0000-0000-000000000000',
      targetAppId: '00000000-0000-0000-0000-000000000000',
      publishTime: '1753-01-01T00:00:00.000Z',
      published: false,
      tags: [],
      description: '',
      stream: null,
      fileSize: 307942,
      lastReloadTime: '2019-12-03T16:21:23.652Z',
      thumbnail:
        '/appcontent/dc3a7943-f6e9-46f9-93fa-c2c20d508093/Linearregression.jpg',
      savedInProductVersion: '12.421.3',
      migrationHash: '',
      dynamicColor: '',
      availabilityStatus: 1,
      privileges: [
        'read',
        'update',
        'delete',
        'publish',
        'offlineaccess',
        'duplicate'
      ],
      schemaPath: 'App'
    }
  ]
}
