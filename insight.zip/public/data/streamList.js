export default {
  streams: [
    {
      id: 'aaec8d41-5201-43ab-809f-3063750dfafd',
      name: 'Everyone',
      privileges: null
    },
    {
      id: 'a70ca8a5-1d59-4cc9-b5fa-6e207978dcaf',
      name: 'Business User Leads',
      privileges: null
    },
    {
      id: '709ba0c1-9555-4cd3-9291-38c225b7a2f9',
      name: 'Business Operations',
      privileges: null
    },
    {
      id: '47205245-5163-410a-a423-62f9f40667fb',
      name: 'Executives',
      privileges: null
    },
    {
      id: 'bf138b70-59d3-471b-92e3-b31761caa348',
      name: 'Marketing',
      privileges: null
    },
    {
      id: '5ad6e067-18b8-4731-9ced-5fcecfc99213',
      name: 'Sales',
      privileges: null
    },
    {
      id: 'ded5c2da-f0e6-41af-bd6b-9df050412b87',
      name: 'Market Access',
      privileges: null
    }
  ]
}
